import Sidebar from "./components/Sidebar";

export default function Beranda () {
    return <Sidebar>
        <h1>Beranda</h1>
    </Sidebar>
}